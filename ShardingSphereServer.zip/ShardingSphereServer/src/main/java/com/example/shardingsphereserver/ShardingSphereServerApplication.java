package com.example.shardingsphereserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShardingSphereServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShardingSphereServerApplication.class, args);
	}

}
